var searchData=
[
  ['master',['master',['../classpgguiapp_1_1PGGuiApp.html#abac82293710b7553c50772ac5b106754',1,'pgguiapp::PGGuiApp']]],
  ['menu',['menu',['../classpgmenubuilder_1_1PGMenuBuilder.html#aa7ebe861ec4eb5e55eb16d3f4d754d5e',1,'pgmenubuilder::PGMenuBuilder']]]
];
