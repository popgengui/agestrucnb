var searchData=
[
  ['get_5fadd_5fcommand_5fparams_5fand_5fargs',['get_add_command_params_and_args',['../classpgmenubuilder_1_1PGMenuBuilder.html#af793740cfaa34421c8ebcc338e5bc3e2',1,'pgmenubuilder::PGMenuBuilder']]],
  ['getlifetablevalue',['getLifeTableValue',['../classpgsimupopresources_1_1PGSimuPopResources.html#ace3ec1ee66c54bfb806a7dfa80755105',1,'pgsimupopresources::PGSimuPopResources']]]
];
